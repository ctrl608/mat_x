#ifndef LIB_H
#define LIB_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define LIMIT 64  // Strassen和CW算法的递归阈值

/* -------------------- 内存管理函数 -------------------- */
double** create_square_matrix(int n) {
    double** mat = (double**)malloc(n * sizeof(double*));
    if (!mat) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < n; i++) {
        mat[i] = (double*)malloc(n * sizeof(double));
        if (!mat[i]) {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }
    }
    return mat;
}

void free_sq_array(int n, double** mat) {
    for (int i = 0; i < n; i++) {
        free(mat[i]);
    }
    free(mat);
}

void initialize_matrix(int n, double** mat) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            mat[i][j] = (double)rand() / RAND_MAX;
        }
    }
}

/* -------------------- 经典矩阵乘法 -------------------- */
void classic(int scale, double** m1, double** m2, double** ans) {
    for (int i = 0; i < scale; i++) {
        for (int j = 0; j < scale; j++) {
            ans[i][j] = 0.0;
            for (int k = 0; k < scale; k++) {
                ans[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }
}

/* -------------------- Strassen算法 -------------------- */
void strassen(int scale, double** m1, double** m2, double** ans) {
    if (scale <= LIMIT) {
        classic(scale, m1, m2, ans);
        return;
    }
    
    int half = scale / 2;
    
    // 创建临时矩阵
    double** T1 = create_square_matrix(half);
    double** T2 = create_square_matrix(half);
    double** T3 = create_square_matrix(half);
    double** T4 = create_square_matrix(half);
    double** T5 = create_square_matrix(half);
    double** T6 = create_square_matrix(half);
    double** T7 = create_square_matrix(half);
    double** temp1 = create_square_matrix(half);
    double** temp2 = create_square_matrix(half);
    
    // T1 = (A11 + A22) * (B11 + B22)
    for (int i = 0; i < half; ++i) {
        for (int j = 0; j < half; ++j) {
            temp1[i][j] = m1[i][j] + m1[i + half][j + half];
            temp2[i][j] = m2[i][j] + m2[i + half][j + half];
        }
    }
    strassen(half, temp1, temp2, T1);
    
    // T2 = (A21 + A22) * B11
    for (int i = 0; i < half; ++i) {
        for (int j = 0; j < half; ++j) {
            temp1[i][j] = m1[i + half][j] + m1[i + half][j + half];
            temp2[i][j] = m2[i][j];
        }
    }
    strassen(half, temp1, temp2, T2);
    
    // T3 = A11 * (B12 - B22)
    for (int i = 0; i < half; ++i) {
        for (int j = 0; j < half; ++j) {
            temp1[i][j] = m1[i][j];
            temp2[i][j] = m2[i][j + half] - m2[i + half][j + half];
        }
    }
    strassen(half, temp1, temp2, T3);
    
    // T4 = A22 * (B21 - B11)
    for (int i = 0; i < half; ++i) {
        for (int j = 0; j < half; ++j) {
            temp1[i][j] = m1[i + half][j + half];
            temp2[i][j] = m2[i + half][j] - m2[i][j];
        }
    }
    strassen(half,temp1,temp2,T4);
    // T5 = (A11 + A12) * B22
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            temp1[i][j]=m1[i][j]+m1[i][j+half];
            temp2[i][j]=m2[i+half][j+half];
        }
    }strassen(half,temp1,temp2,T5);
    // T6 = (A21 - A11) * (B11 + B12)
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            temp1[i][j]=m1[i+half][j]-m1[i][j];
            temp2[i][j]=m2[i][j]+m2[i][j+half];
        }
    }strassen(half,temp1,temp2,T6);
    // T7 = (A12 - A22) * (B21 + B22)
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            temp1[i][j]=m1[i][j+half]-m1[i+half][j+half];
            temp2[i][j]=m2[i+half][j]+m2[i+half][j+half];
        }
    }strassen(half,temp1,temp2,T7);
        // 直接合并计算结果矩阵的四个子块,节省内存
    for (int i=0; i<scale ;++i){
        for (int j=0;j<scale ; ++j){
            if (i<half){
                if(j<half){
                    ans[i][j]=T1[i][j]+T4[i][j]-T5[i][j]+T7[i][j];// C11 = T1 + T4 - T5 + T7
                }else{
                    ans[i][j]=T3[i][j-half]+T5[i][j-half];// C12 = T3 + T5
                }
            }else{
                if(j<half){
                    ans[i][j]=T2[i-half][j]+T4[i-half][j];// C21 = T2 + T4
                }else{
                    ans[i][j]=T1[i-half][j-half]-T2[i-half][j-half]+T3[i-half][j-half]+T6[i-half][j-half];// C22 = T1 - T2 + T3 + T6
                }
            }
        }
    }
    free_sq_array(half, T1);
    free_sq_array(half, T2);
    free_sq_array(half, T3);
    free_sq_array(half, T4);
    free_sq_array(half, T5);
    free_sq_array(half, T6);
    free_sq_array(half, T7);
    free_sq_array(half, temp1);
    free_sq_array(half, temp2);
}
void CW(int scale, double **m1, double **m2, double **ans) {
    if(scale <= LIMIT) {
        classic(scale, m1, m2, ans);
        return;
    }
    
    int half = scale / 2;
    
    // 分配临时矩阵
    double **S1 = create_square_matrix(half);
    double **S2 = create_square_matrix(half);
    double **S3 = create_square_matrix(half);
    double **S4 = create_square_matrix(half);
    double **T1 = create_square_matrix(half);
    double **T2 = create_square_matrix(half);
    double **T3 = create_square_matrix(half);
    double **T4 = create_square_matrix(half);
    double **R1 = create_square_matrix(half);
    double **R2 = create_square_matrix(half);
    double **R3 = create_square_matrix(half);
    double **R4 = create_square_matrix(half);
    double **R5 = create_square_matrix(half);
    double **R6 = create_square_matrix(half);
    double **R7 = create_square_matrix(half);
    double **C1 = create_square_matrix(half);
    double **C2 = create_square_matrix(half);
    double **C3 = create_square_matrix(half);
    double **C4 = create_square_matrix(half);
    double **C5 = create_square_matrix(half);
    double **C6 = create_square_matrix(half);
    double **C7 = create_square_matrix(half);
    double **A11 = create_square_matrix(half);
    double **B11 = create_square_matrix(half);
    double **A12 = create_square_matrix(half);
    double **B21 = create_square_matrix(half);
    double **B22 = create_square_matrix(half);
    double **A22 = create_square_matrix(half);
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            A12[i][j]=m1[i][j+half];
            A22[i][j]=m1[i+half][j+half];
            B21[i][j]=m2[i+half][j];
            B22[i][j]=m2[i+half][j+half];
            A11[i][j] = m1[i][j];
            B11[i][j] = m2[i][j];
        }
    }
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            S1[i][j]=m1[i+half][j]+m1[i+half][j+half];
        }
    }
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            S2[i][j]=S1[i][j]-m1[i][j];
        }
    }
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            S3[i][j]=m1[i][j]-m1[i+half][j];
        }
    }   
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            S4[i][j]=m1[i][j+half]-S2[i][j];
        }
    }   
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            T1[i][j]=m2[i][j+half]-m2[i][j];
            T2[i][j]=m2[i+half][j+half]-T1[i][j];
        }
    }
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            T3[i][j]=m2[i+half][j+half]-m2[i][j+half];
            T4[i][j]=T2[i][j]-m2[i+half][j];
        }
    }
    CW(half,A11,B11,R1);
    CW(half,A12,B21,R2);
    CW(half,S4,B22,R3);
    CW(half,A22,T4,R4);
    CW(half,S1,T1,R5);
    CW(half,S2,T2,R6);
    CW(half,S3,T3,R7);
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            C1[i][j]=R1[i][j]+R2[i][j];
            C2[i][j]=R1[i][j]+R6[i][j];
        }
    }
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            C3[i][j]=C2[i][j]+R7[i][j];
            C4[i][j]=C2[i][j]+R5[i][j];
        }
    }
    for(int i=0; i<half; ++i){
        for(int j=0; j<half; ++j){
            C5[i][j]=C4[i][j]+R3[i][j];
            C6[i][j]=C3[i][j]-R4[i][j];
            C7[i][j]=C3[i][j]+R5[i][j];
        }
    }
    for (int i=0; i<scale ;++i){
        for (int j=0;j<scale ; ++j){
            if (i<half){
                if(j<half){
                    ans[i][j]=C1[i][j];
                }else{
                    ans[i][j]=C5[i][j-half];
                }
            }else{
                if(j<half){
                    ans[i][j]=C6[i-half][j];
                }else{
                    ans[i][j]=C7[i-half][j-half];
                }
            }
        }
    }
    
    // 释放所有临时矩阵
    free_sq_array(half, S1);
    free_sq_array(half, S2);
    free_sq_array(half, S3);
    free_sq_array(half, S4);
    free_sq_array(half, T1);
    free_sq_array(half, T2);
    free_sq_array(half, T3);
    free_sq_array(half, T4);
    free_sq_array(half, R1);
    free_sq_array(half, R2);
    free_sq_array(half, R3);
    free_sq_array(half, R4);
    free_sq_array(half, R5);
    free_sq_array(half, R6);
    free_sq_array(half, R7);
    free_sq_array(half, C1);
    free_sq_array(half, C2);
    free_sq_array(half, C3);
    free_sq_array(half, C4);
    free_sq_array(half, C5);
    free_sq_array(half, C6);
    free_sq_array(half, C7);
    free_sq_array(half, A11);
    free_sq_array(half, B11);
    free_sq_array(half, A12);
    free_sq_array(half, B21);
    free_sq_array(half, B22);
    free_sq_array(half, A22);
    return;
}
/* -------------------- 训练质心 (K-means) -------------------- */
void train_centroids(int scale, int num_subspaces, int num_centroids_per_subspace, 
                     double ***centroids, double **mat) {
    
    int sub_dim = scale / num_subspaces;
    int max_iters = 30; // K-means迭代次数

    for (int sub = 0; sub < num_subspaces; ++sub) {
        // 随机初始化质心：从矩阵中随机选取 num_centroids_per_subspace 行
        for (int c = 0; c < num_centroids_per_subspace; ++c) {
            int rand_row = rand() % scale;
            for (int d = 0; d < sub_dim; ++d) {
                centroids[sub][c][d] = mat[rand_row][sub*sub_dim + d];
            }
        }

        // K-means迭代
        int *labels = (int*)malloc(scale * sizeof(int));
        if(!labels){ fprintf(stderr, "malloc failed\n"); exit(EXIT_FAILURE); }

        for (int iter = 0; iter < max_iters; ++iter) {
            // 1. 分配样本到最近质心
            for (int i = 0; i < scale; ++i) {
                double min_dist = INFINITY;
                int best_c = 0;
                for (int c = 0; c < num_centroids_per_subspace; ++c) {
                    double dist = 0.0;
                    for (int d = 0; d < sub_dim; ++d) {
                        double diff = mat[i][sub*sub_dim + d] - centroids[sub][c][d];
                        dist += diff*diff;
                    }
                    if (dist < min_dist) {
                        min_dist = dist;
                        best_c = c;
                    }
                }
                labels[i] = best_c;
            }

            // 2. 更新质心为各簇的均值
            // 初始化临时质心累加数组
            double **new_centroids = (double**)malloc(num_centroids_per_subspace * sizeof(double*));
            if(!new_centroids){ fprintf(stderr, "malloc failed\n"); exit(EXIT_FAILURE); }
            int *counts = (int*)malloc(num_centroids_per_subspace * sizeof(int));
            if(!counts){ fprintf(stderr, "malloc failed\n"); exit(EXIT_FAILURE); }
            for (int c = 0; c < num_centroids_per_subspace; ++c) {
                new_centroids[c] = (double*)malloc(sub_dim* sizeof(double));
                if(!new_centroids[c]){ fprintf(stderr, "malloc failed\n"); exit(EXIT_FAILURE); }
            }

            for (int i = 0; i < scale; ++i) {
                int c = labels[i];
                counts[c]++;
                for (int d = 0; d < sub_dim; ++d) {
                    for (int c = 0; c < num_centroids_per_subspace; ++c) counts[c] = 0;
                    for (int c = 0; c < num_centroids_per_subspace; ++c)
                        for (int d = 0; d < sub_dim; ++d)
                            new_centroids[c][d] = 0.0;

                    new_centroids[c][d] += mat[i][sub*sub_dim + d];
                }
            }

            for (int c = 0; c < num_centroids_per_subspace; ++c) {
                if (counts[c] == 0) continue; // 防止除零
                for (int d = 0; d < sub_dim; ++d) {
                    centroids[sub][c][d] = new_centroids[c][d] / counts[c];
                }
                free(new_centroids[c]);
            }
            free(new_centroids);
            free(counts);
        }
        free(labels);
    }
}

/* -------------------- 编码 -------------------- */
void encode(int scale, double **mat ,int num_subspaces, int num_centroids_per_subspace,
        double ***centroids,
        int **codebook){ // 引入codebook,存储每个簇对应的质心索引
    const int sub_dims = scale / num_subspaces; // 每个子空间的维度
    for (int row = 0; row < scale; ++row){ // 遍历每一行
        for (int sub = 0; sub < num_subspaces; ++sub){ // 遍历该行在每个子空间对应的"子行"

            double min_dist = INFINITY; // 初始化最小距离为无穷大
            int best_centroid = -1; // 初始化最佳质心索引
            for (int centroid = 0; centroid < num_centroids_per_subspace; ++centroid){
                double dist = 0.0; // 计算该子行与质心的欧式距离平方
                for (int dim = 0; dim < sub_dims; ++dim){
                    double diff = mat[row][sub*sub_dims + dim] - centroids[sub][centroid][dim];
                    dist += diff*diff;
                }
                if (dist < min_dist){
                    min_dist = dist;
                    best_centroid = centroid;
                }
            }
            codebook[row][sub] = best_centroid; // 写回codebook
        }
    }
}

/* -------------------- 构建查找表 -------------------- */
void build_table(int scale, double **matrix_B,
                 int num_subspaces, int num_centroids_per_subspace,
                 double ***centroids,
                 double ***table) {

    const int sub_dim = scale / num_subspaces;

    for (int col = 0; col < scale; ++col){ // 遍历B的列
        for (int sub = 0; sub < num_subspaces; ++sub){ // 遍历子空间
            for (int k = 0; k < num_centroids_per_subspace; ++k){
                double dot = 0.0;
                for (int d = 0; d < sub_dim; ++d){
                    dot += centroids[sub][k][d] * matrix_B[col][sub*sub_dim + d];
                }
                table[col][sub][k] = dot;
            }
        }
    }
}

/* -------------------- 使用查找表计算结果 -------------------- */
void compute_result(int scale, int num_subspaces, int num_centroids_per_subspace,
                    int **codebook,
                    double ***lookup_table,
                    double **result) {

    for (int row = 0; row < scale; ++row){
        for (int col = 0; col < scale; ++col){
            double sum = 0.0;
            for (int sub = 0; sub < num_subspaces; ++sub){
                int centroid_index = codebook[row][sub];
                sum += lookup_table[col][sub][centroid_index];
            }
            result[row][col] = sum;
        }
    }
}

/* -------------------- 打印前10列 -------------------- */
void print10(int scale, double **mat){
    for (int j = 0; j < 10 && j < scale; ++j)
        printf("%f ", mat[0][j]);
    printf("\n");
}

/* -------------------- 计算误差 -------------------- */
void compute_error(int scale, double **approx, double **exact){
    double mse = 0.0;       // 均方误差
    double max_err = 0.0;   // 最大绝对误差

    for(int i = 0; i < scale; ++i){
        for(int j = 0; j < scale; ++j){
            double diff = approx[i][j] - exact[i][j];
            mse += diff * diff;
            if(fabs(diff) > max_err)
                max_err = fabs(diff);
        }
    }
    mse /= (scale * scale);

    printf("MSE (mean squared error): %lf\n", mse);
    printf("Max absolute error: %lf\n", max_err);
}







#endif